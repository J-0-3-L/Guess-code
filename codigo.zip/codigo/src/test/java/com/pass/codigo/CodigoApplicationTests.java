package com.pass.codigo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodigoApplicationTests {

	@Test
	void contextLoads() {
	}

}
